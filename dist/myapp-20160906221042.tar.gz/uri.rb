require "uri"
uri= URI("")